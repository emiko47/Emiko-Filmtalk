import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { UpdateItemCommand } from '@aws-sdk/client-dynamodb';

const ddbClient = new DynamoDBClient({ region: 'us-east-2' });

async function addDislike (event) {
    const username = event.username;
    const card_id = event.card_id;

    // Transaction parameters
    const params = {
        TableName: 'MovieCards',
        Key: { card_id: card_id },
        UpdateExpression: `
            SET #dislikers = list_append(if_not_exists(#dislikers, :emptyList), :username),
                #dislike_no = #dislike_no + :inc,
                #likers = list_remove(if_not_exists(#likers, :emptyList), :username),
                #like_no = #like_no - :dec
            `,
        ConditionExpression: 'NOT contains(#dislikers, :username)',
        ExpressionAttributeNames: {
            '#dislikers': 'dislikers',
            '#dislike_no': 'dislike_no',
            '#likers': 'likers',
            '#like_no': 'like_no'
        },
        ExpressionAttributeValues: {
            ':username': [username],
            ':emptyList': [],
            ':inc': 1,
            ':dec': 1
        },
        ReturnValues: 'UPDATED_NEW'
    };

    try {
        const command = new UpdateItemCommand(params);
        await ddbClient.send(command);
        return {
            headers: {
                "Access-Control-Allow-Origin": "*", 
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
              },
            statusCode: 200,
            body: JSON.stringify({ message: 'Dislike added successfully' })
        };
    } catch (error) {
        return {
            headers: {
                "Access-Control-Allow-Origin": "*", 
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
              },
            statusCode: 500,
            body: JSON.stringify({ message: 'Failed to add dislike', error: error.message })
        };
    }
};
const _addDislike = addDislike;
export { _addDislike as addDislike };
